package db5;

import java.util.Scanner;

public class StudentDelete {
//    public void studentDelete(){
//        Scanner scan = new Scanner(System.in);
//        StudentDAO stdDAO = new StudentDAO();
//
//        System.out.print("학번 입력: ");
//        String stdNo = scan.nextLine();
//
//        StudentDTO stdDTO = new StudentDTO(stdNo, stdName, stdYear, stdAddress, stdBirthday, dptNo);
//        stdDAO.deleteStudent(stdDTO);
//    }
}
